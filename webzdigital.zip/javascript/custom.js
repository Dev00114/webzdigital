$('.slick-current').onClick = function(){
    alert();
}